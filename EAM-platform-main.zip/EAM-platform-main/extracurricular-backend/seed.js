const sequelize = require('./config/database');
const User = require('./models/User');
const Activity = require('./models/Activity');
const bcrypt = require('bcryptjs');

const seed = async () => {
  await sequelize.sync({ force: true });

  const adminPass = await bcrypt.hash('admin123', 10);
  await User.create({ name: 'Admin', email: 'admin@school.com', password: adminPass, role: 'admin' });

  await Activity.bulkCreate([
    { name: 'Robotics Club', category: 'club', schedule: 'Wed 3-5 PM' },
    { name: 'Basketball Team', category: 'sport', schedule: 'Mon, Thu 4-6 PM' },
    { name: 'Annual Science Fair', category: 'event', schedule: '2025-12-10' }
  ]);

  console.log('Seeded');
  process.exit();
};

seed();