const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Activity = sequelize.define('Activity', {
  name: { type: DataTypes.STRING, allowNull: false },
  description: DataTypes.TEXT,
  category: {
    type: DataTypes.ENUM('club', 'sport', 'event', 'workshop'),
    allowNull: false
  },
  schedule: DataTypes.TEXT
});

module.exports = Activity;