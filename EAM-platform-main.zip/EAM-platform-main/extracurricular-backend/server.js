// server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const sequelize = require('./config/database');

const eventsRouter = require('./routes/events');

const app = express();
app.use(cors());
app.use(express.json());

// === ROUTES ===
app.get('/', (req, res) => {
  res.json({
    message: 'Extracurricular Backend API',
    db: 'extracurricular_db',
    status: 'Connected!',
    endpoints: {
      events: '/api/events/upcoming'
    }
  });
});

app.use('/api/events', eventsRouter);

// 404
app.use((req, res) => res.status(404).json({ error: 'Not found' }));

// === DATABASE ===
(async () => {
  try {
    await sequelize.authenticate();
    console.log('MySQL CONNECTED: extracurricular_db');

    await sequelize.sync({ alter: false });
    console.log('Models synced: users, events, activities, registrations');

  } catch (error) {
    console.error('DB Connection FAILED:', error.message);
  }
})();

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server LIVE: http://localhost:${PORT}`);
});