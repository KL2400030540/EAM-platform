// controllers/activityController.js
const Activity = require('../models/Activity');

const getAll = async (req, res) => {
  try {
    const activities = await Activity.findAll({
      order: [['day', 'ASC'], ['time', 'ASC']]
    });
    res.json(activities);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = { getAll };