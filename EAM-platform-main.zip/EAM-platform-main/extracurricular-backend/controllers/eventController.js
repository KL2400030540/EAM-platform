// controllers/eventController.js
const Event = require('../models/Event');
const { Op } = require('sequelize');

const getUpcoming = async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const events = await Event.findAll({
      where: {
        date: { [Op.gte]: today }
      },
      order: [['date', 'ASC']]
    });

    console.log('Sending events:', events); // ← SEE IN TERMINAL
    res.json(events);
  } catch (error) {
    console.error('EVENT ERROR:', error.message);
    res.status(500).json({ error: 'Failed to fetch events' });
  }
};

module.exports = { getUpcoming };