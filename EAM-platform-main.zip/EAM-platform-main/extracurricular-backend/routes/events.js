// routes/events.js
const express = require('express');
const router = express.Router();
const Event = require('../models/Event');
const { Op } = require('sequelize');

router.get('/upcoming', async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const events = await Event.findAll({
      where: {
        date: { [Op.gte]: today }
      },
      order: [['date', 'ASC']]
    });
    res.json(events);
  } catch (error) {
    console.error('EVENT FETCH ERROR:', error); // ← SEE FULL ERROR
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

module.exports = router;