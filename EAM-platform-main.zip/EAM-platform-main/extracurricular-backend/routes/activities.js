// routes/activities.js
const express = require('express');
const router = express.Router();
const { getAll } = require('../controllers/activityController');

router.get('/', getAll);

module.exports = router;