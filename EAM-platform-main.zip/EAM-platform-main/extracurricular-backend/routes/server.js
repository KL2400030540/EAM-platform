const activityRouter = require('./routes/activities');
app.use('/api/activities', activityRouter);